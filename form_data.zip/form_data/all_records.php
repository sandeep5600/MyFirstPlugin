<?php


global $wpdb;
 //global $table_prefix;
$table=$wpdb->prefix .'form_data';
$sql = "select* from $table";
$result=$wpdb->get_results($sql);
//print_r($result);

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="https://xpertidea.com/nightteam/Sandeep/snapkart/wp-content/plugins/form_data/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.12.1/datatables.min.css"/>
  </head>
  <body class="container all_recode_body" >
      <div class="all_recode_body" >
    <h2 class="from-hd">All Records</h2>
    <table id="dtBasicExample" class="table table-striped table-hover table-bordered>" cellspacing="0" width="100%">
        <thead>
           <tr class="table-danger table-heading">
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Department</th>
                <th>Employee Designation</th>
                <th>Employee Id</th>
                <th>Address</th>
                <th>Gender</th>
                <th>Age</th>

            </tr>
        </thead>
        <tbody>
            <?php
    foreach($result as $list){ 
    ?>
           <tr class="table-warning">
                <td><?php echo $list->id ?></td>
                <td><?php echo $list->name ?></td>
                <td><?php echo $list->email ?></td>
                <td><?php echo $list->department ?></td>
                <td><?php echo $list->emp_designation ?></td>
                <td><?php echo $list->employee_id ?></td>
                <td><?php echo $list->address ?></td>
                <td><?php echo $list->gender ?></td>
                <td><?php echo $list->age ?></td>
            </tr>
           <?php
}
    ?>
        </tbody>
        <tfoot>
            <tr class="table-danger table-heading">
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Department</th>
                <th>Employee Designation</th>
                <th>Employee Id</th>
                <th>Address</th>
                <th>Gender</th>
                <th>Age</th>
            </tr>
        </tfoot>
    </table>
  </div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.12.1/datatables.min.js"></script>
    <script>
        $(document).ready(function () {
        $('#dtBasicExample').DataTable();
        $('.dataTables_length').addClass('bs-select');
        });
    </script>

  </body>
</html>



