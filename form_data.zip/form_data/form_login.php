<?php

   $err =array();   
   
         // $name = $_POST['name'];
        // $email = $_POST['email'];
        //   $department = $_POST['department'];
        //   $emp_designation = $_POST['employee_designation'];
        //       $employee_id = $_POST['employee_id'];
        //       $address = $_POST['address'];
        //       $password = $_POST['password'];
        //       $cpassword = $_POST['cpassword'];
        //       $gender = $_POST['gender'];
        //       $age = $_POST['age'];
        
        
if(isset($_POST['submit'])){
   
    // name validation 
    $name = $_POST['name'];
     if (empty($_POST['name'])){
     $err['name'] ="name is requried";  //0
         }else{
         $name = $_POST['name'];
     }
     
      // email validation 
      
     if (empty($_POST['email'])){
     $err['email'] ="email is requried";  //1
         }else{
         $email = $_POST['email'];
     }
     
     // email validation 
      
     if (empty($_POST['department'])){
     $err['department'] ="department is requried";
         }else{
         $department = $_POST['department'];
     }
     
     if (empty($_POST['employee_designation'])){
     $err['employee_designation'] ="employee designation is requried";
         }else{
         $emp_designation = $_POST['employee_designation'];
     }
     
     if (empty($_POST['employee_id'])){
     $err['employee_id'] ="employee ID is requried";
         }else{
         $employee_id = $_POST['employee_id'];
     }
     
     if (empty($_POST['address'])){
     $err['address'] ="address is requried";
         }else{
         $address = $_POST['address'];
     }
     
   
     if (empty($_POST['gender'])){
     $err['gender'] ="gender is requried";
         }else{
       $gender = $_POST['gender'];
     } 
     
     if (empty($_POST['age'])){
     $err['age'] ="age is requried";
         }else{
      $age = $_POST['age'];
     } 


if(count($err)==0){
    

global $wpdb;
$table=$wpdb->prefix .'form_data';

 $sql = $wpdb->query("INSERT INTO $table (name, email, department,emp_designation,employee_id,address,gender,age) 
 VALUES ('$name', '$email', '$department','$emp_designation','$employee_id','$address','$gender','$age')");

// echo $sql = "INSERT INTO $table (name, email, department,emp_designation,employee_id,address,gender,age) VALUES ('$name', '$email', '$department','$emp_designation','$employee_id','$address','$gender','$age')";
// $result=$wpdb->$sql;

//echo '<pre>';print_r($result);die;
    if ($sql) {
  echo("<script> alert('New record created successfully'); </script>");
    //echo "New record created successfully21";
    } 
    else {
   echo("<script> alert('All feilds are required'); </script>");
    echo "All feilds are required";
    }

}
    

}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--<title>Bootstrap demo</title>-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

  <link rel="stylesheet" href="https://xpertidea.com/nightteam/Sandeep/snapkart/wp-content/plugins/form_data/style.css">
 
    <style>
    .err {color: #FF0000;}
    </style>
        
  </head>
  <body>
    
    
<!--Login form start-->
    
<div class="container login-from-div" >
    <h2 class="from-hd">Employee registration</h2>
    
<form class="row g-3 container login-from" method="POST">

  <div class="col-md-6">
    <label for="inputName" class="form-label">Full Name</label><span class="err">*<?php echo $err['name'] ;?></span>
    <input type="text" class="form-control" name="name"  value="<?php echo $name?>"  id="inputName" >
    
  </div>
  
  <div class="col-md-6">
    <label for="inputEmail4" class="form-label">Email</label><span class="err">*<?php echo $err['email']?></span>
    <input type="email" class="form-control" name="email"  value="<?php echo $email?>"id="inputEmail4">
  </div>
  <div class="col-md-6">
    <label for="inputDepartment" class="form-label">Department</label><span class="err">*<?php echo  $err['department']?></span>
    <input type="text" class="form-control" name="department"  value="<?php echo $department?>" id="inputDepartment 
    "placeholder="PHP,Digital marketing etc">
  </div>
  <div class="col-md-6">
    <label for="inputdesignation"  class="form-label">Employee Designation </label><span class="err">*<?php echo $err['employee_designation']?></span>
    <input type="text" class="form-control" name="employee_designation" value="<?php echo $emp_designation?>"  id="employeedesignation " placeholder="web-devloper,Seo executive etc">
  </div>
  <div class="col-md-6">
    <label for="inputEmployeeID" class="form-label">Employee ID</label><span class="err">*<?php echo $err['employee_id']?></span>
    <input type="text" class="form-control" name="employee_id" value="<?php echo $employee_id?>" id="EmployeeID" placeholder="WBit1234 ">
  </div>
  
  <div class="col-md-6">
    <label for="inputAddress" class="form-label">Address</label><span class="err">*<?php  echo $err['address']?></span>
    <input type="text" class="form-control" name="address" value="<?php echo $address?>" id="inputAddress" placeholder="1234 Main St">
  </div>
  
  
   <fieldset class="col-md-6">
   
    <legend class="col-form-label col-sm-2 pt-0">Gender </legend><span class="err">*<?php echo $err['gender']?></span>
  <div class="form-check form-check-inline">
  
  <input class="form-check-input" type="radio" name="gender" id="inlineRadio1" value="male"  checked="checked" >
  <label class="form-check-label" for="inlineRadio1" >Male </label>
    </div>
    <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="gender" id="inlineRadio2" value="female">
  <label class="form-check-label" for="inlineRadio2">Female</label>
    </div>

 </fieldset>


  <div class="col-md-6">
    <label for="inputAge" class="form-label">Age</label><span class="err">*<?php echo $err['age']?></span>
    <input type="text" class="form-control" name="age" value="<?php  echo $age?>" id="inputAge">
  </div>

  
  <div class="d-grid gap-2">
    <button type="submit"  class="btn btn-primary"  name="submit"> submit</button>
   
  </div>
</form>
    </div>
    
<!--Login form end-->

 
      <!--<input type="submit" name ="submit" value="submit">-->
    
     <!--<button class="btn btn-primary" type="button">Button</button>-->
<!-- <div class="col-md-6">-->
    <!--<label for="inputPassword4" class="form-label">Password</label><span class="err">*<?php echo $err['password']?></span>-->
  <!--  <input type="password" class="form-control"  name="password"  id="inputPassword4">-->
  <!--</div>-->
  <!-- <div class="col-md-6">-->
    <!--<label for="inputPassword4" class="form-label">confirm Password</label><span class="err">*<?php echo $err['cpassword']?></span>-->
  <!--  <input type="password" class="form-control"  name="cpassword"  id="inputPassword4">-->
  <!--</div>-->
    
  </body>
</html>

<?php

// echo $sql = "INSERT INTO $table (name, email, department,emp_designation,employee_id,address,gender,age) VALUES ('$name', '$email', '$department','$emp_designation','$employee_id','$address','$gender','$age')";
//$result=$wpdb->$sql;

// print_r($wpdb);



    //$data =  mysqli_query($link, $sql);   

//echo '<pre>';print_r($wpdb);die;
 //global $table_prefix;
 //$sql = "select* from $table";
//$result=$wpdb->get_results($sql);
//print_r($result);

?>

