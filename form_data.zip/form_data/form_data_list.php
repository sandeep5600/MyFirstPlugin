<?php


global $wpdb;
 //global $table_prefix;
$table=$wpdb->prefix .'form_data';
$sql = "select* from $table";
$result=$wpdb->get_results($sql);
//print_r($result);

?>

<table border="1">
    <tr>
        <td>Personid</td>
        <td>LastName</td>
        <td>FirstName</td>
        <td>Age</td>
    </tr>
    <?php
    foreach($result as $list){ 
    ?>
 
        <tr>
        
        <td><?php echo $list->Personid ?></td>
        <td><?php echo $list->LastName ?></td>
        <td><?php echo $list->FirstName ?></td>
        <td><?php echo $list->Age ?></td>
        </tr>
        <?php
}
    ?>
    
</table>
<h1> hello</h1>
