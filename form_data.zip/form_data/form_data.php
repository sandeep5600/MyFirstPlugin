<?php
/*
 Plugin Name: Form Data
 Plugin URI:  https://wordpress.org/Form-Data
 Description: A simple wordpress plugins.
 Author: sandeep
 Author URI: https://wordpress.org/
 Version:1.0

*/
?>
<?php

register_activation_hook(__FILE__,'form_data_activate');
register_deactivation_hook(__FILE__,'form_data_deactivate');

function form_data_activate(){
   
  
    global $wpdb;
   // global $table_prefix;
    $table=$wpdb->prefix .'form_data';
    
$sql=  "CREATE TABLE $table (   

    id int(50) NOT NULL AUTO_INCREMENT,
name varchar(255) NOT NULL,
email varchar(255),
department varchar(255),
emp_designation varchar(255),
employee_id varchar(255),
address varchar(255),
gender varchar(255),
age int(10),

    PRIMARY KEY (id)
)
";
 require_once ABSPATH . 'wp-admin/includes/upgrade.php';
dbDelta( $sql );


// $wpdb->query($sql);
// global $wpdb;
// $table_name = $wpdb->prefix . 'liveshoutbox';
// $charset_collate = $wpdb->get_charset_collate();
// $sql = "CREATE TABLE $table_name (
//   id mediumint(9) NOT NULL AUTO_INCREMENT,
//   time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
//   name tinytext NOT NULL,
//   text text NOT NULL,
//   url varchar(55) DEFAULT '' NOT NULL,
//   PRIMARY KEY  (id)
// ) $charset_collate;";
//  require_once ABSPATH . 'wp-admin/includes/upgrade.php';
//	dbDelta( $sql );


}

function form_data_deactivate(){
     global $wpdb;
    //global $table_prefix;
     $table=$wpdb->prefix .'form_data';
    $sql = "DROP TABLE IF EXISTS $table";
 $wpdb->query($sql);
  // dbDelta( $sql ); 
}
add_action('admin_menu','form_data_menu');
function form_data_menu(){
    
  
 add_menu_page('form_data','Form Data','administrator','form_data','get_register');
  add_submenu_page('form_data','my submenu', 'All records', 'manage_options','all-records','get_all_records');
  
 // add_submenu_page('form_data','my submenu1', 'my submenu', 'manage_options','form-submenu1','mySubmenuPageFunction1');
    
}

    function get_register (){
    include('form_login.php');  
    // echo "wellcome hai bhai 850";
    //include('form_data_list.php');
  
    }
    function get_all_records (){
    include('all_records.php');
    // echo "wellcome hai bhai";
    
    }  
    
    
    // function mySubmenuPageFunction1 (){
    //   echo "fir se wellcome hai bhai";
    
    // }  



add_shortcode('form_data_list_sort','get_all_records');
add_shortcode('get_register_list_sort','get_register');




?>